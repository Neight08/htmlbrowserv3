$(document).ready(start);

function start() {
$("#mybutton").click(inputtext);
}

function inputtext() {
var ourtext=$("#mytext").val();
    $("#site").attr("src",ourtext)
}